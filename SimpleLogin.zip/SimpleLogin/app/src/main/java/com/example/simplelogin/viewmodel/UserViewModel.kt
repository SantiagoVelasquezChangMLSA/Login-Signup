package com.example.simplelogin.viewmodel

import android.net.http.HttpException
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.simplelogin.data.LoginUserRequest
import com.example.simplelogin.data.LoginUserResponse
import com.example.simplelogin.data.RegisterUserRequest
import com.example.simplelogin.data.RegisterUserResponse
import com.example.simplelogin.service.UserService
import kotlinx.coroutines.launch
import java.lang.Exception

class UserViewModel(private val userService: UserService) : ViewModel() {

    private val _login = MutableLiveData<LoginUserResponse> ()
    val login: LiveData<LoginUserResponse> = _login

    private val _register = MutableLiveData<RegisterUserResponse> ()
    val register: LiveData<RegisterUserResponse> = _register

    fun registerUser(user: RegisterUserRequest){

        viewModelScope.launch {

            try {
                val response = userService.addUser(user)
                _register.value = response
            }
            catch (e: Exception){

            }
        }
    }


    fun loginUser(user: LoginUserRequest){

        _login.value = null

        viewModelScope.launch {

            try {
                val response = userService.loginUser(user)
                _login.value = response
            }

            catch (e: Exception){

            }
        }
    }

}