package com.example.simplelogin.data

data class RegisterUserRequest(
    val name: String,
    val email: String,
    val password: String
)
