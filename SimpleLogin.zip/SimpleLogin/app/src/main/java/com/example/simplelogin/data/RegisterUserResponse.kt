package com.example.simplelogin.data

data class RegisterUserResponse(
    val message: String
)