package com.example.simplelogin.data

data class LoginUserRequest(
    val email: String,
    val password: String,

)